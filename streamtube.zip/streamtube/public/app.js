const state = {
  recent: JSON.parse(localStorage.getItem("streamtube_recent") || "[]"),
  currentQuery: "",
  toastTimer: null,
};

const $ = (selector) => document.querySelector(selector);

const views = {
  home: $("#homeView"),
  results: $("#resultsView"),
  watch: $("#watchView"),
};

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>"']/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
  }[char]));
}

function formatDate(value) {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  return new Intl.DateTimeFormat(undefined, { dateStyle: "medium" }).format(date);
}

function formatNumber(value) {
  if (value == null) return "";
  const n = Number(value);
  if (!Number.isFinite(n)) return "";
  return new Intl.NumberFormat(undefined, { notation: "compact", maximumFractionDigits: 1 }).format(n);
}

function saveRecent(query) {
  query = query.trim();
  if (!query) return;
  state.recent = [query, ...state.recent.filter((item) => item.toLowerCase() !== query.toLowerCase())].slice(0, 8);
  localStorage.setItem("streamtube_recent", JSON.stringify(state.recent));
  renderRecent();
}

function renderRecent() {
  const container = $("#recentSearches");
  if (!state.recent.length) {
    container.innerHTML = `<span style="color:#59616e;font-size:12px;padding:8px 10px;">No searches yet.</span>`;
    return;
  }
  container.innerHTML = state.recent.map((query) =>
    `<button class="recent-search" data-query="${escapeHtml(query)}">${escapeHtml(query)}</button>`
  ).join("");

  container.querySelectorAll(".recent-search").forEach((button) => {
    button.addEventListener("click", () => search(button.dataset.query));
  });
}

function videoCard(item) {
  return `
    <article class="video-card" data-video-id="${escapeHtml(item.id)}">
      <div class="thumb">
        <img src="${escapeHtml(item.thumbnail)}" alt="" loading="lazy" referrerpolicy="no-referrer">
        <span class="play-badge">▶</span>
      </div>
      <h3>${escapeHtml(item.title)}</h3>
      <p class="video-meta">${escapeHtml(item.channelTitle)}${item.publishedAt ? " • " + escapeHtml(formatDate(item.publishedAt)) : ""}</p>
    </article>
  `;
}

function relatedCard(item) {
  return `
    <article class="related-card" data-video-id="${escapeHtml(item.id)}">
      <div class="thumb">
        <img src="${escapeHtml(item.thumbnail)}" alt="" loading="lazy" referrerpolicy="no-referrer">
      </div>
      <div>
        <h3>${escapeHtml(item.title)}</h3>
        <p>${escapeHtml(item.channelTitle)}</p>
      </div>
    </article>
  `;
}

function bindVideoCards(root) {
  root.querySelectorAll("[data-video-id]").forEach((card) => {
    card.addEventListener("click", () => openVideo(card.dataset.videoId));
  });
}

function showView(name) {
  Object.entries(views).forEach(([key, element]) => {
    element.classList.toggle("hidden", key !== name);
  });

  document.querySelectorAll(".nav-item").forEach((item) => item.classList.remove("active"));
  if (name === "home") document.querySelector('[data-nav="home"]')?.classList.add("active");
}

function skeletons(count = 8) {
  return Array.from({ length: count }, () => `
    <div class="skeleton-card">
      <div class="skeleton skeleton-thumb"></div>
      <div class="skeleton line wide"></div>
      <div class="skeleton line"></div>
    </div>
  `).join("");
}

async function api(path) {
  const response = await fetch(path, { headers: { "Accept": "application/json" } });
  let data = {};
  try { data = await response.json(); } catch {}
  if (!response.ok) throw new Error(data.error || "Request failed.");
  return data;
}

async function search(query) {
  query = String(query || "").trim();
  if (!query) return;

  closeUrlModal();
  state.currentQuery = query;
  $("#searchInput").value = query;
  $("#resultsTitle").textContent = query;
  $("#resultsCount").textContent = "";
  $("#resultsGrid").innerHTML = "";
  $("#resultsLoading").classList.remove("hidden");
  $("#resultsLoading").innerHTML = skeletons(10);
  $("#resultsEmpty").classList.add("hidden");
  showView("results");

  saveRecent(query);

  try {
    const data = await api(`/api/search?q=${encodeURIComponent(query)}&limit=18`);
    $("#resultsLoading").classList.add("hidden");
    $("#resultsGrid").innerHTML = data.items.length
      ? data.items.map(videoCard).join("")
      : "";
    $("#resultCount").textContent = `${data.items.length} results`;
    $("#resultsEmpty").classList.toggle("hidden", data.items.length !== 0);
    bindVideoCards($("#resultsGrid"));
  } catch (error) {
    $("#resultsLoading").classList.add("hidden");
    $("#resultsGrid").innerHTML = "";
    $("#resultsEmpty").classList.remove("hidden");
    $("#resultsEmpty h3").textContent = "Search unavailable";
    $("#resultsEmpty p").textContent = error.message;
  }
}

async function openVideo(id, push = true) {
  if (!/^[A-Za-z0-9_-]{11}$/.test(id || "")) {
    showToast("That YouTube video ID is not valid.");
    return;
  }

  if (push) history.pushState({ id }, "", `/watch/${encodeURIComponent(id)}`);
  showView("watch");
  window.scrollTo({ top: 0, behavior: "smooth" });

  $("#youtubePlayer").src =
    `https://www.youtube.com/embed/${encodeURIComponent(id)}?rel=0&playsinline=1&origin=${encodeURIComponent(location.origin)}`;

  $("#videoInfo").innerHTML = `
    <div class="info-loading">
      <div class="skeleton line wide"></div>
      <div class="skeleton line"></div>
    </div>
  `;
  $("#relatedList").innerHTML = skeletons(4);

  const [videoResult, relatedResult] = await Promise.allSettled([
    api(`/api/video?id=${encodeURIComponent(id)}`),
    api(`/api/related?id=${encodeURIComponent(id)}`)
  ]);

  if (videoResult.status === "fulfilled") {
    const video = videoResult.value;
    const meta = [
      video.channelTitle,
      video.views ? `${formatNumber(video.views)} views` : "",
      video.publishedAt ? formatDate(video.publishedAt) : ""
    ].filter(Boolean).join(" • ");

    $("#videoInfo").innerHTML = `
      <h1>${escapeHtml(video.title)}</h1>
      <div class="info-meta">${escapeHtml(meta)}</div>
      <div class="description">${escapeHtml(video.description || "No description available.")}</div>
    `;
  } else {
    $("#videoInfo").innerHTML = `
      <h1>Video</h1>
      <div class="info-meta">YouTube player loaded directly.</div>
      <div class="description">${escapeHtml(videoResult.reason?.message || "Video details could not be loaded.")}</div>
    `;
  }

  if (relatedResult.status === "fulfilled") {
    const items = relatedResult.value.items || [];
    $("#relatedList").innerHTML = items.length
      ? items.map(relatedCard).join("")
      : `<div class="empty-state"><p>No related videos were found.</p></div>`;
    bindVideoCards($("#relatedList"));
  } else {
    $("#relatedList").innerHTML = `<div class="empty-state"><p>${escapeHtml(relatedResult.reason?.message || "Related videos unavailable.")}</p></div>`;
  }
}

async function openFromUrl(input) {
  const raw = String(input || "").trim();
  if (!raw) return;

  try {
    const data = await api(`/api/parse?input=${encodeURIComponent(raw)}`);
    if (!data.id) throw new Error("Enter a valid YouTube URL or 11-character video ID.");
    closeUrlModal();
    openVideo(data.id);
  } catch (error) {
    $("#urlError").textContent = error.message;
  }
}

function openUrlModal() {
  $("#urlModal").classList.remove("hidden");
  $("#urlError").textContent = "";
  $("#urlInput").value = "";
  setTimeout(() => $("#urlInput").focus(), 30);
}

function closeUrlModal() {
  $("#urlModal").classList.add("hidden");
}

function showToast(message) {
  const toast = $("#toast");
  toast.textContent = message;
  toast.classList.add("show");
  clearTimeout(state.toastTimer);
  state.toastTimer = setTimeout(() => toast.classList.remove("show"), 2500);
}

function route() {
  const path = location.pathname;
  const hash = location.hash;

  if (path.startsWith("/watch/")) {
    const id = decodeURIComponent(path.split("/")[2] || "");
    openVideo(id, false);
    return;
  }

  if (hash.startsWith("#/watch/")) {
    openVideo(decodeURIComponent(hash.split("/")[2] || ""), false);
    return;
  }

  if (hash === "#/popular") {
    search("popular videos");
    return;
  }

  showView("home");
  renderHome();
}

function renderHome() {
  renderRecent();
  const homeGrid = $("#homeGrid");

  if (!state.recent.length) {
    homeGrid.innerHTML = "";
    $("#homeEmpty").classList.remove("hidden");
    return;
  }

  $("#homeEmpty").classList.add("hidden");
  $("#homeHeading").textContent = "Recent searches";
  $("#homeSubheading").textContent = "Pick up where you left off.";

  // Recent search chips are intentionally local; no API request is made until selected.
  homeGrid.innerHTML = state.recent.slice(0, 4).map((query) => `
    <article class="video-card" data-search="${escapeHtml(query)}">
      <div class="thumb" style="display:grid;place-items:center;background:linear-gradient(135deg,#171b24,#21141a);">
        <div style="font-size:35px;color:#ff335f;">⌕</div>
      </div>
      <h3>${escapeHtml(query)}</h3>
      <p class="video-meta">Search YouTube again</p>
    </article>
  `).join("");

  homeGrid.querySelectorAll("[data-search]").forEach((card) => {
    card.addEventListener("click", () => search(card.dataset.search));
  });
}

$("#searchForm").addEventListener("submit", (event) => {
  event.preventDefault();
  search($("#searchInput").value);
});

$("#pasteButton").addEventListener("click", openUrlModal);
$("#openUrlButton").addEventListener("click", openUrlModal);
$("#modalClose").addEventListener("click", closeUrlModal);
$("#urlModal").addEventListener("click", (event) => {
  if (event.target === $("#urlModal")) closeUrlModal();
});
$("#urlForm").addEventListener("submit", (event) => {
  event.preventDefault();
  openFromUrl($("#urlInput").value);
});
$("#menuButton").addEventListener("click", () => $("#sidebar").classList.toggle("open"));

window.addEventListener("popstate", route);
window.addEventListener("hashchange", route);

renderRecent();
route();
