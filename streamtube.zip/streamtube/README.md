# StreamTube

StreamTube is a lightweight, GitHub-ready YouTube search and playback web app built for **Cloudflare Workers**.

It uses:

- Cloudflare Workers for the backend/API layer
- Cloudflare Workers Static Assets for the frontend
- YouTube Data API v3 for search and metadata
- YouTube's supported embedded player for playback

It **does not download, scrape, decrypt, proxy, or re-host YouTube video files**.

## Project structure

```text
streamtube/
├── src/
│   └── index.js
├── public/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── package.json
├── wrangler.toml
├── .gitignore
└── README.md
```

## 1. Create the GitHub repository

Create a new empty repository on GitHub named `streamtube`.

Then, from this project folder:

```bash
git init
git add .
git commit -m "Initial StreamTube app"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/streamtube.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username.

## 2. Install dependencies

You need Node.js/npm installed.

```bash
npm install
```

The only development dependency is Wrangler.

## 3. Create and configure the YouTube API key

Create a Google Cloud project, enable **YouTube Data API v3**, and create an API key.

Do **not** put the key in `public/app.js`, HTML, or any frontend file.

Set it as a Cloudflare Worker secret:

```bash
npx wrangler secret put YOUTUBE_API_KEY
```

Wrangler will prompt you to enter the value.

The Worker reads it as:

```js
env.YOUTUBE_API_KEY
```

For local development, you can create a `.dev.vars` file:

```text
YOUTUBE_API_KEY="YOUR_KEY_HERE"
```

`.dev.vars` is ignored by Git, so it should never be committed.

## 4. Run locally

Start the Cloudflare development server:

```bash
npm run dev
```

Wrangler will give you a local address, usually something similar to:

```text
http://localhost:8787
```

Open that address in your browser.

Search requires a configured YouTube API key. Direct YouTube video playback uses the official YouTube embed player.

## 5. Deploy with Wrangler

Authenticate Wrangler:

```bash
npx wrangler login
```

Set the production secret if you have not already:

```bash
npx wrangler secret put YOUTUBE_API_KEY
```

Then deploy:

```bash
npm run deploy
```

Cloudflare will deploy the Worker and the `public/` static assets together.

After deployment, Wrangler will print your Worker URL.

## 6. Connect a custom Cloudflare domain

If your domain is already managed by Cloudflare:

1. Open the Cloudflare dashboard.
2. Go to **Workers & Pages**.
3. Open the `streamtube` Worker.
4. Open **Settings / Domains & Routes** (the exact UI wording can change).
5. Add your custom domain.
6. Follow Cloudflare's DNS/TLS setup prompts.

You can also use a subdomain such as:

```text
stream.example.com
```

## API routes

The Worker exposes these GET endpoints:

### Search

```text
/api/search?q=your+search&limit=18
```

Searches YouTube videos through YouTube Data API v3.

### Video metadata

```text
/api/video?id=VIDEO_ID
```

Gets title, description, channel, publish date, views, and other supported metadata.

### Related videos

```text
/api/related?id=VIDEO_ID
```

Uses the video's title to find additional YouTube videos through the documented Data API.

### YouTube URL parsing

```text
/api/parse?input=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DVIDEO_ID
```

Safely extracts supported YouTube video IDs without fetching or scraping the video page.

## YouTube playback

StreamTube embeds videos using YouTube's supported IFrame player:

```text
https://www.youtube.com/embed/VIDEO_ID
```

The browser loads and plays the video from YouTube. StreamTube never receives or stores the underlying video file.

## API quota note

YouTube Data API requests consume quota. Search requests are substantially more expensive than simple video metadata requests, so this project:

- Limits search result counts
- Caps user search input length
- Uses short edge caching for repeated API requests
- Keeps the API key on the Worker
- Avoids unnecessary polling

Check your Google Cloud API Console if you reach the project's quota.

## Security notes

The frontend never contains the YouTube API key.

The Worker:

- Validates video IDs
- Restricts API functionality to GET requests
- Limits search query length
- Uses YouTube's documented APIs
- Does not proxy YouTube media
- Does not bypass DRM or access controls

For a public production deployment, consider adding Cloudflare rate limiting or another abuse-control layer if the application becomes heavily used.

## License

Use and modify the project as appropriate for your own application. Review YouTube API Services terms and Cloudflare terms before operating a public service.
