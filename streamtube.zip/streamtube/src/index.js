const JSON_HEADERS = {
  "content-type": "application/json; charset=UTF-8",
  "cache-control": "no-store",
};

function json(data, status = 200, extraHeaders = {}) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { ...JSON_HEADERS, ...extraHeaders },
  });
}

function getVideoId(input) {
  if (!input) return null;

  const value = String(input).trim();

  // Plain YouTube video ID.
  if (/^[A-Za-z0-9_-]{11}$/.test(value)) return value;

  try {
    const url = new URL(value);

    const host = url.hostname.toLowerCase().replace(/^www\./, "");

    if (host === "youtu.be") {
      const id = url.pathname.split("/").filter(Boolean)[0];
      return /^[A-Za-z0-9_-]{11}$/.test(id || "") ? id : null;
    }

    if (
      host === "youtube.com" ||
      host === "m.youtube.com" ||
      host === "music.youtube.com" ||
      host === "youtube-nocookie.com"
    ) {
      const queryId = url.searchParams.get("v");
      if (queryId && /^[A-Za-z0-9_-]{11}$/.test(queryId)) return queryId;

      const parts = url.pathname.split("/").filter(Boolean);
      const marker = parts[0];
      if (["embed", "shorts", "live", "v"].includes(marker)) {
        const id = parts[1];
        return /^[A-Za-z0-9_-]{11}$/.test(id || "") ? id : null;
      }
    }
  } catch {
    return null;
  }

  return null;
}

function cleanText(value, max = 5000) {
  return String(value || "").replace(/\s+/g, " ").trim().slice(0, max);
}

function normalizeItem(item) {
  const id = item?.id?.videoId || item?.id;
  const snippet = item?.snippet || {};
  if (!id || !/^[A-Za-z0-9_-]{11}$/.test(id)) return null;

  return {
    id,
    title: cleanText(snippet.title, 300),
    description: cleanText(snippet.description, 1000),
    channelTitle: cleanText(snippet.channelTitle, 200),
    channelId: snippet.channelId || "",
    publishedAt: snippet.publishedAt || null,
    thumbnail:
      snippet.thumbnails?.maxres?.url ||
      snippet.thumbnails?.high?.url ||
      snippet.thumbnails?.medium?.url ||
      snippet.thumbnails?.default?.url ||
      `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
  };
}

async function youtubeRequest(path, params, env, ctx) {
  if (!env.YOUTUBE_API_KEY) {
    throw new Error("YouTube API key is not configured on this Worker.");
  }

  const url = new URL(`https://www.googleapis.com/youtube/v3/${path}`);
  for (const [key, value] of Object.entries(params)) {
    if (value !== undefined && value !== null && value !== "") {
      url.searchParams.set(key, value);
    }
  }
  url.searchParams.set("key", env.YOUTUBE_API_KEY);

  // A short edge cache reduces repeated identical API calls.
  const cache = caches.default;
  const cacheKey = new Request(url.toString(), { method: "GET" });
  const cached = await cache.match(cacheKey);
  if (cached) return cached;

  const response = await fetch(url);
  const body = await response.text();

  if (!response.ok) {
    let detail = "YouTube API request failed.";
    try {
      const parsed = JSON.parse(body);
      detail = parsed?.error?.message || detail;
    } catch {}
    throw new Error(detail);
  }

  const result = new Response(body, {
    status: 200,
    headers: {
      "content-type": "application/json; charset=UTF-8",
      "cache-control": "public, max-age=60",
    },
  });

  ctx.waitUntil(cache.put(cacheKey, result.clone()));
  return result;
}

async function handleSearch(url, env, ctx) {
  const q = cleanText(url.searchParams.get("q"), 120);
  if (!q) return json({ error: "Enter something to search for." }, 400);

  const maxResults = Math.min(
    Math.max(Number(url.searchParams.get("limit")) || 12, 1),
    25
  );

  const response = await youtubeRequest(
    "search",
    {
      part: "snippet",
      q,
      type: "video",
      maxResults: String(maxResults),
      regionCode: "US",
      safeSearch: "moderate",
      videoEmbeddable: "true",
    },
    env,
    ctx
  );

  const data = await response.json();
  return json({
    query: q,
    items: (data.items || []).map(normalizeItem).filter(Boolean),
    nextPageToken: data.nextPageToken || null,
  }, 200, { "cache-control": "public, max-age=60" });
}

async function handleVideo(url, env, ctx) {
  const id = getVideoId(url.searchParams.get("id"));
  if (!id) return json({ error: "That does not look like a valid YouTube video ID or URL." }, 400);

  const response = await youtubeRequest(
    "videos",
    {
      part: "snippet,contentDetails,statistics",
      id,
    },
    env,
    ctx
  );

  const data = await response.json();
  const item = data.items?.[0];
  if (!item) return json({ error: "YouTube could not find that video." }, 404);

  const normalized = normalizeItem(item);
  return json({
    ...normalized,
    duration: item.contentDetails?.duration || null,
    views: item.statistics?.viewCount || null,
    likes: item.statistics?.likeCount || null,
  }, 200, { "cache-control": "public, max-age=120" });
}

async function handleRelated(url, env, ctx) {
  const id = getVideoId(url.searchParams.get("id"));
  if (!id) return json({ error: "Invalid video ID." }, 400);

  // Fetch the video's title first, then use a lightweight search to find
  // related results. This uses only documented YouTube Data API methods.
  const videoResponse = await youtubeRequest(
    "videos",
    { part: "snippet", id },
    env,
    ctx
  );
  const videoData = await videoResponse.json();
  const title = videoData.items?.[0]?.snippet?.title || "";

  const terms = title
    .replace(/[^\p{L}\p{N}\s-]/gu, "")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 8)
    .join(" ");

  if (!terms) return json({ items: [] });

  const response = await youtubeRequest(
    "search",
    {
      part: "snippet",
      q: terms,
      type: "video",
      maxResults: "8",
      regionCode: "US",
      safeSearch: "moderate",
      videoEmbeddable: "true",
    },
    env,
    ctx
  );

  const data = await response.json();
  const items = (data.items || [])
    .map(normalizeItem)
    .filter(Boolean)
    .filter((item) => item.id !== id)
    .slice(0, 8);

  return json({ items }, 200, { "cache-control": "public, max-age=120" });
}

async function handleApi(request, env, ctx) {
  const url = new URL(request.url);

  try {
    if (url.pathname === "/api/search") return await handleSearch(url, env, ctx);
    if (url.pathname === "/api/video") return await handleVideo(url, env, ctx);
    if (url.pathname === "/api/related") return await handleRelated(url, env, ctx);
    if (url.pathname === "/api/parse") {
      const id = getVideoId(url.searchParams.get("input"));
      return json({ id });
    }

    return json({ error: "API route not found." }, 404);
  } catch (error) {
    return json(
      {
        error: error?.message || "Something went wrong.",
      },
      500
    );
  }
}

export default {
  async fetch(request, env, ctx) {
    const url = new URL(request.url);

    if (url.pathname.startsWith("/api/")) {
      if (request.method !== "GET") {
        return json({ error: "Method not allowed." }, 405, {
          allow: "GET",
        });
      }
      return handleApi(request, env, ctx);
    }

    // Serve the SPA/static files through Cloudflare Workers Static Assets.
    const assetResponse = await env.ASSETS.fetch(request);
    if (assetResponse.status !== 404) return assetResponse;

    // Client-side routes such as /watch/VIDEO_ID fall back to index.html.
    if (request.method === "GET" && !url.pathname.includes(".")) {
      const indexUrl = new URL("/", request.url);
      return env.ASSETS.fetch(new Request(indexUrl, request));
    }

    return assetResponse;
  },
};
